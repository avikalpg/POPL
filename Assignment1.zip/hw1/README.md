CS350A Assignment1

Group Members:
Avikalp Kumar Gupta     12178
Harshvardhan Solanki    12293
Prachi Gupta            12485

Assumptions:

Q.2.1   The function returns the message 'The 2 Lists are not of equal size' in case the two lists passed as arguments don't have equal sizes.
